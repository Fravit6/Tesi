-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Gen 29, 2021 alle 17:23
-- Versione del server: 10.1.32-MariaDB
-- Versione PHP: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `youcare`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `medici`
--

CREATE TABLE `medici` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `medici`
--

INSERT INTO `medici` (`id`, `username`, `password`, `nome`) VALUES
(1, 'medico1', '$2y$10$bx23Ip3138O9OegRdhNhi.jwgAdTeoid7TFCdBN2fKcWEzeqo1Jfy', 'Nome Medico');

-- --------------------------------------------------------

--
-- Struttura della tabella `questionari`
--

CREATE TABLE `questionari` (
  `userId` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `temp` decimal(10,1) DEFAULT NULL,
  `malDiGola` tinyint(1) DEFAULT NULL,
  `malDiTesta` tinyint(1) DEFAULT NULL,
  `doloriMuscolari` tinyint(1) DEFAULT NULL,
  `nausea` tinyint(1) DEFAULT NULL,
  `tosse` tinyint(1) DEFAULT NULL,
  `respiroCorto` tinyint(1) DEFAULT NULL,
  `umore` tinyint(1) DEFAULT NULL,
  `saturazioneOssigeno` decimal(10,1) DEFAULT NULL,
  `freqRespiro` decimal(10,1) DEFAULT NULL,
  `freqCardiaca` decimal(10,1) DEFAULT NULL,
  `pressioneMassima` decimal(10,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `questionari`
--

INSERT INTO `questionari` (`userId`, `data`, `temp`, `malDiGola`, `malDiTesta`, `doloriMuscolari`, `nausea`, `tosse`, `respiroCorto`, `umore`, `saturazioneOssigeno`, `freqRespiro`, `freqCardiaca`, `pressioneMassima`) VALUES
(1, '2021-01-22 16:48:31', '37.0', 1, 0, 0, 0, 0, 1, 0, '100.0', '10.0', '80.0', '150.0'),
(2, '2021-01-14 17:32:11', '42.0', 0, 0, 0, 0, 0, 0, 0, '92.5', '12.0', '82.5', '142.0'),
(2, '2021-01-16 22:29:29', '39.0', 1, 0, 0, 0, 0, 1, 0, '100.0', '10.0', '80.0', '150.0'),
(2, '2021-01-17 16:32:56', '37.7', 0, 0, 0, 0, 0, 0, 0, '100.0', '10.0', '80.0', '150.0'),
(2, '2021-01-22 11:33:09', '37.1', 0, 0, 0, 0, 0, 1, 0, '100.0', '10.0', '80.0', '150.0'),
(3, '2021-01-17 13:12:45', '37.7', 0, 0, 0, 0, 0, 0, 0, '100.0', '10.0', '80.0', '150.0'),
(3, '2021-01-22 18:32:49', '38.0', 0, 0, 0, 1, 0, 0, 0, '100.0', '10.0', '80.0', '150.0'),
(6, '2021-01-06 08:00:00', '38.0', 1, 1, 1, 1, 1, 0, 1, '100.0', '10.0', '80.0', '150.0'),
(6, '2021-01-07 08:00:00', '41.0', 0, 0, 0, 0, 0, 0, 0, '100.0', '10.0', '80.0', '150.0'),
(6, '2021-01-13 17:35:10', '41.5', 0, 0, 1, 0, 0, 1, 0, '99.5', '16.0', '86.5', '146.0'),
(6, '2021-01-14 17:36:20', '42.5', 0, 0, 1, 0, 0, 1, 0, '99.5', '16.0', '86.5', '146.0'),
(6, '2021-01-16 21:56:46', '42.8', 1, 1, 0, 1, 1, 0, 1, '98.5', '15.0', '84.5', '145.0'),
(6, '2021-01-17 16:32:39', '38.0', 1, 0, 0, 0, 0, 1, 0, '97.0', '17.0', '87.0', '147.0'),
(6, '2021-01-21 17:50:07', '40.6', 1, 0, 0, 0, 0, 0, 0, '100.0', '10.0', '80.0', '150.0'),
(6, '2021-01-22 11:32:42', '37.0', 1, 0, 0, 1, 0, 1, 0, '99.5', '13.0', '77.0', '156.0'),
(51, '2021-01-22 16:48:41', '37.4', 1, 0, 0, 0, 0, 1, 0, '100.0', '10.0', '80.0', '150.0');

-- --------------------------------------------------------

--
-- Struttura della tabella `risposte`
--

CREATE TABLE `risposte` (
  `id` int(11) NOT NULL,
  `topicId` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `autoreId` int(11) NOT NULL,
  `nomeAutore` varchar(100) NOT NULL,
  `testo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `risposte`
--

INSERT INTO `risposte` (`id`, `topicId`, `data`, `autoreId`, `nomeAutore`, `testo`) VALUES
(1, 1, '2021-01-14 00:00:00', 1, 'Simona Gambardella', 'Risposta di Simona Gambardella: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam egestas leo quis purus porta finibus. Interdum et malesuada fames ac ante ipsum primis in faucibus. '),
(2, 1, '2021-01-15 00:00:00', 6, 'Francesco Vitale', 'Risposta di Vitale Francesco: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam egestas leo quis purus porta finibus. Interdum et malesuada fames ac ante ipsum primis in faucibus.');

-- --------------------------------------------------------

--
-- Struttura della tabella `topic`
--

CREATE TABLE `topic` (
  `id` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `idAutore` int(11) NOT NULL,
  `nomeAutore` varchar(200) NOT NULL,
  `titolo` varchar(200) NOT NULL,
  `testo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `topic`
--

INSERT INTO `topic` (`id`, `data`, `idAutore`, `nomeAutore`, `titolo`, `testo`) VALUES
(1, '2021-01-08 00:00:00', 6, 'Francesco Vitale', 'Titolo topic 1', 'Testo Topic 1: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam egestas leo quis purus porta finibus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aliquam lacinia non nulla vel gravida. Suspendisse consectetur rhoncus ante, eget volutpat odio egestas vel. Curabitur euismod at nibh vitae faucibus. Duis sed odio est. Vestibulum sit amet enim condimentum, hendrerit lacus porta, suscipit risus.'),
(2, '2021-01-10 00:00:00', 1, 'Simona Gambardella', 'Titolo topic 2', 'Testo Topic 2: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam egestas leo quis purus porta finibus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aliquam lacinia non nulla vel gravida. Suspendisse consectetur rhoncus ante, eget volutpat odio egestas vel. Curabitur euismod at nibh vitae faucibus. Duis sed odio est. Vestibulum sit amet enim condimentum, hendrerit lacus porta, suscipit risus.');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `userId` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(16) NOT NULL,
  `codFiscale` varchar(21) NOT NULL,
  `codTessera` int(20) NOT NULL,
  `notifiche` tinyint(1) NOT NULL DEFAULT '1',
  `idUtenteGestore` int(11) DEFAULT NULL,
  `idMedicoCurante` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`userId`, `nome`, `cognome`, `codFiscale`, `codTessera`, `notifiche`, `idUtenteGestore`, `idMedicoCurante`, `email`, `password`) VALUES
(1, 'Simona', 'Gambardella', 'GMBSMN', 12345, 1, NULL, 0, 'test2@test2.it', '$2y$10$bx23Ip3138O9OegRdhNhi.jwgAdTeoid7TFCdBN2fKcWEzeqo1Jfy'),
(2, 'Gian Luigi', 'Vitale', 'VTLGLG', 1234, 0, 6, 1, NULL, NULL),
(3, 'Angelamaria', 'Gisolfi', 'GSLNGL', 12345, 1, 6, 1, NULL, NULL),
(4, 'Simone', 'Vitale', 'VTLSMN', 1234, 1, 6, 1, NULL, NULL),
(6, 'Francesco', 'Vitale', 'VTLFNC95H12H703K', 8038, 0, NULL, 1, 'test@test.it', '$2y$10$bx23Ip3138O9OegRdhNhi.jwgAdTeoid7TFCdBN2fKcWEzeqo1Jfy'),
(51, 'Antonello', 'Gambardella', 'GMBNTN', 123456789, 1, 1, 0, NULL, NULL),
(53, 'Prova Familiare', 'Prova Cognome', 'PRVFML', 1234, 1, 6, 1, NULL, NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `medici`
--
ALTER TABLE `medici`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indici per le tabelle `questionari`
--
ALTER TABLE `questionari`
  ADD PRIMARY KEY (`userId`,`data`);

--
-- Indici per le tabelle `risposte`
--
ALTER TABLE `risposte`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `autoreId` (`autoreId`),
  ADD KEY `topicId` (`topicId`);

--
-- Indici per le tabelle `topic`
--
ALTER TABLE `topic`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `idAutore` (`idAutore`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `codFiscale` (`codFiscale`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `userId` (`userId`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `medici`
--
ALTER TABLE `medici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `risposte`
--
ALTER TABLE `risposte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `topic`
--
ALTER TABLE `topic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `questionari`
--
ALTER TABLE `questionari`
  ADD CONSTRAINT `utenteAutore` FOREIGN KEY (`userId`) REFERENCES `utenti` (`userId`);

--
-- Limiti per la tabella `risposte`
--
ALTER TABLE `risposte`
  ADD CONSTRAINT `autoreId` FOREIGN KEY (`autoreId`) REFERENCES `utenti` (`userId`) ON DELETE NO ACTION,
  ADD CONSTRAINT `topicId` FOREIGN KEY (`topicId`) REFERENCES `topic` (`id`) ON DELETE CASCADE;

--
-- Limiti per la tabella `topic`
--
ALTER TABLE `topic`
  ADD CONSTRAINT `idAutore` FOREIGN KEY (`idAutore`) REFERENCES `utenti` (`userId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
